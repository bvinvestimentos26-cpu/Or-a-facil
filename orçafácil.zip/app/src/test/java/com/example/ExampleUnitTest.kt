package com.example

import com.example.data.model.AppUser
import com.example.util.Formatters
import com.example.util.SecurityUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPasswordHashing() {
        val hash1 = SecurityUtils.hashPassword("admin123")
        val hash2 = SecurityUtils.hashPassword("admin123")
        val hash3 = SecurityUtils.hashPassword("wrongpass")

        assertEquals(hash1, hash2)
        assertTrue(SecurityUtils.verifyPassword("admin123", hash1))
        assertFalse(SecurityUtils.verifyPassword("wrongpass", hash1))
    }

    @Test
    fun testAppUserStatus() {
        val now = System.currentTimeMillis()
        val userActive = AppUser(
            id = 1,
            name = "Test User",
            email = "user@test.com",
            phone = "11999999999",
            businessName = "Test Business",
            status = AppUser.STATUS_ACTIVE,
            planName = AppUser.PLAN_PRO,
            trialStartDate = now,
            trialEndDate = now + (7 * 86400000L)
        )
        assertTrue(userActive.isAccessAllowed)
        assertEquals("Assinatura Ativa", userActive.effectiveStatusLabel)

        val userTrial = AppUser(
            id = 2,
            name = "Trial User",
            email = "trial@test.com",
            phone = "11888888888",
            businessName = "Trial Business",
            status = AppUser.STATUS_TRIAL,
            planName = AppUser.PLAN_TRIAL,
            trialStartDate = now,
            trialEndDate = now + (7 * 86400000L)
        )
        assertTrue(userTrial.isTrialActive)
        assertTrue(userTrial.isAccessAllowed)
        assertTrue(userTrial.remainingTrialDays >= 6)

        val userExpired = AppUser(
            id = 3,
            name = "Expired User",
            email = "expired@test.com",
            phone = "11777777777",
            businessName = "Expired Business",
            status = AppUser.STATUS_EXPIRED,
            trialStartDate = now - (14 * 86400000L),
            trialEndDate = now - (7 * 86400000L)
        )
        assertFalse(userExpired.isAccessAllowed)
        assertEquals("Assinatura Vencida", userExpired.effectiveStatusLabel)
    }

    @Test
    fun testCurrencyFormatting() {
        val formatted = Formatters.formatCurrency(1250.50)
        assertTrue(formatted.contains("1.250,50") || formatted.contains("1250,50"))
    }
}
