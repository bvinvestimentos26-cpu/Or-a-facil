package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.AdminConfig
import com.example.data.model.AppUser
import com.example.data.model.Budget
import com.example.data.model.UserProfile
import com.example.data.repository.BudgetRepository
import com.example.util.Formatters
import com.example.util.SecurityUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object BudgetList : Screen()
    data class BudgetForm(val budgetId: Long? = null) : Screen()
    data class BudgetDetail(val budgetId: Long) : Screen()
    object Profile : Screen()
    object AdminLogin : Screen()
    object AdminDashboard : Screen()
    data class Paywall(val reason: String = "trial_expired") : Screen()
}

data class BudgetFormState(
    val editingBudgetId: Long? = null,
    val clientName: String = "",
    val clientPhone: String = "",
    val serviceType: String = "",
    val serviceDescription: String = "",
    val quantity: String = "1",
    val unit: String = "un",
    val materialCost: String = "0,00",
    val laborCost: String = "0,00",
    val otherCosts: String = "0,00",
    val profitMarginPercent: Double = 20.0,
    val customFinalAmount: String = "",
    val isCustomFinalAmount: Boolean = false,
    val estimatedDeadline: String = "3 a 5 dias úteis",
    val paymentMethod: String = "Pix, Dinheiro ou Cartão",
    val validityDays: Int = 15,
    val notes: String = "",
    val status: String = Budget.STATUS_PENDING,
    val isCalculated: Boolean = false,
    val errorMessage: String? = null
) {
    val materialCostDouble: Double get() = Formatters.parseNumber(materialCost)
    val laborCostDouble: Double get() = Formatters.parseNumber(laborCost)
    val otherCostsDouble: Double get() = Formatters.parseNumber(otherCosts)
    val quantityDouble: Double get() = quantity.replace(",", ".").toDoubleOrNull() ?: 1.0

    val subtotalCost: Double get() = materialCostDouble + laborCostDouble + otherCostsDouble
    val profitAmount: Double get() = subtotalCost * (profitMarginPercent / 100.0)
    val calculatedFinalAmount: Double get() = subtotalCost + profitAmount

    val effectiveFinalAmount: Double
        get() = if (isCustomFinalAmount && customFinalAmount.isNotBlank()) {
            Formatters.parseNumber(customFinalAmount)
        } else {
            calculatedFinalAmount
        }
}

data class DashboardStats(
    val totalCount: Int = 0,
    val pendingCount: Int = 0,
    val approvedCount: Int = 0,
    val rejectedCount: Int = 0,
    val totalApprovedValue: Double = 0.0,
    val totalPendingValue: Double = 0.0
)

data class AdminMetrics(
    val totalUsers: Int = 0,
    val trialUsers: Int = 0,
    val activeProUsers: Int = 0,
    val expiredUsers: Int = 0,
    val blockedUsers: Int = 0,
    val totalSubscriptions: Int = 0,
    val monthlyRevenue: Double = 0.0
)

class BudgetViewModel(
    application: Application,
    private val repository: BudgetRepository
) : AndroidViewModel(application) {

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _screenHistory = mutableListOf<Screen>()

    // Current user subscription
    val currentUser: StateFlow<AppUser?> = repository.getCurrentUser()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Admin state
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    val adminConfig: StateFlow<AdminConfig?> = repository.getAdminConfig()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allUsers: StateFlow<List<AppUser>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _adminSearchQuery = MutableStateFlow("")
    val adminSearchQuery: StateFlow<String> = _adminSearchQuery.asStateFlow()

    private val _adminStatusFilter = MutableStateFlow("TODOS")
    val adminStatusFilter: StateFlow<String> = _adminStatusFilter.asStateFlow()

    val filteredAdminUsers: StateFlow<List<AppUser>> = combine(
        allUsers,
        _adminSearchQuery,
        _adminStatusFilter
    ) { users, query, filter ->
        users.filter { user ->
            val matchesQuery = query.isBlank() ||
                    user.name.contains(query, ignoreCase = true) ||
                    user.businessName.contains(query, ignoreCase = true) ||
                    user.email.contains(query, ignoreCase = true) ||
                    user.phone.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                "TODOS" -> true
                "TESTE_GRATIS" -> user.status == AppUser.STATUS_TRIAL
                "ATIVO" -> user.status == AppUser.STATUS_ACTIVE
                "VENCIDO" -> user.status == AppUser.STATUS_EXPIRED
                "BLOQUEADO" -> user.status == AppUser.STATUS_BLOCKED
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminMetrics: StateFlow<AdminMetrics> = allUsers.combine(adminConfig) { users, config ->
        val proPrice = config?.proPlanPriceMonthly ?: 29.90
        val trial = users.filter { it.status == AppUser.STATUS_TRIAL }
        val active = users.filter { it.status == AppUser.STATUS_ACTIVE }
        val expired = users.filter { it.status == AppUser.STATUS_EXPIRED }
        val blocked = users.filter { it.status == AppUser.STATUS_BLOCKED }

        val revenue = active.sumOf { it.planPrice }

        AdminMetrics(
            totalUsers = users.size,
            trialUsers = trial.size,
            activeProUsers = active.size,
            expiredUsers = expired.size,
            blockedUsers = blocked.size,
            totalSubscriptions = active.size,
            monthlyRevenue = revenue
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AdminMetrics())

    // All budgets from database
    val allBudgets: StateFlow<List<Budget>> = repository.getAllBudgets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("TODOS")
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    // Filtered list
    val filteredBudgets: StateFlow<List<Budget>> = combine(
        allBudgets,
        _searchQuery,
        _statusFilter
    ) { budgets, query, filter ->
        budgets.filter { budget ->
            val matchesQuery = query.isBlank() ||
                    budget.clientName.contains(query, ignoreCase = true) ||
                    budget.serviceType.contains(query, ignoreCase = true) ||
                    budget.serviceDescription.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                "TODOS" -> true
                "PENDENTE" -> budget.status == Budget.STATUS_PENDING
                "APROVADO" -> budget.status == Budget.STATUS_APPROVED
                "RECUSADO" -> budget.status == Budget.STATUS_REJECTED
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dashboard summary statistics
    val dashboardStats: StateFlow<DashboardStats> = allBudgets.combine(allBudgets) { list, _ ->
        val pending = list.filter { it.status == Budget.STATUS_PENDING }
        val approved = list.filter { it.status == Budget.STATUS_APPROVED }
        val rejected = list.filter { it.status == Budget.STATUS_REJECTED }
        DashboardStats(
            totalCount = list.size,
            pendingCount = pending.size,
            approvedCount = approved.size,
            rejectedCount = rejected.size,
            totalApprovedValue = approved.sumOf { it.finalAmount },
            totalPendingValue = pending.sumOf { it.finalAmount }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardStats())

    // User Profile
    val userProfile: StateFlow<UserProfile?> = repository.getUserProfile()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Form State
    private val _formState = MutableStateFlow(BudgetFormState())
    val formState: StateFlow<BudgetFormState> = _formState.asStateFlow()

    // Feedback message
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    fun clearSnackbarMessage() {
        _snackbarMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    // Navigation Methods
    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            _screenHistory.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (_screenHistory.isNotEmpty()) {
            _currentScreen.value = _screenHistory.removeAt(_screenHistory.size - 1)
            return true
        }
        if (_currentScreen.value !is Screen.Home) {
            _currentScreen.value = Screen.Home
            return true
        }
        return false
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setStatusFilter(filter: String) {
        _statusFilter.value = filter
    }

    fun setAdminSearchQuery(query: String) {
        _adminSearchQuery.value = query
    }

    fun setAdminStatusFilter(filter: String) {
        _adminStatusFilter.value = filter
    }

    // User Access & Subscription Verification
    fun isCurrentAccessAllowed(): Boolean {
        val user = currentUser.value ?: return true
        return user.isAccessAllowed
    }

    fun checkAccessAndStartBudget() {
        val user = currentUser.value
        if (user != null && !user.isAccessAllowed) {
            val reason = if (user.status == AppUser.STATUS_BLOCKED) "blocked" else "trial_expired"
            navigateTo(Screen.Paywall(reason))
            return
        }
        startNewBudget()
    }

    // Form Initialization & Field Updates
    fun startNewBudget() {
        val profile = userProfile.value
        _formState.value = BudgetFormState(
            editingBudgetId = null,
            estimatedDeadline = "3 a 5 dias úteis",
            paymentMethod = profile?.defaultPaymentTerms ?: "50% de entrada + 50% na conclusão",
            validityDays = profile?.defaultValidityDays ?: 15,
            notes = profile?.defaultNotes ?: "Garantia de 90 dias. Orçamento válido pelo prazo informado.",
            profitMarginPercent = 20.0
        )
        navigateTo(Screen.BudgetForm(null))
    }

    fun editBudget(budget: Budget) {
        _formState.value = BudgetFormState(
            editingBudgetId = budget.id,
            clientName = budget.clientName,
            clientPhone = budget.clientPhone,
            serviceType = budget.serviceType,
            serviceDescription = budget.serviceDescription,
            quantity = if (budget.quantity % 1.0 == 0.0) budget.quantity.toInt().toString() else budget.quantity.toString(),
            unit = budget.unit,
            materialCost = String.format(java.util.Locale("pt", "BR"), "%.2f", budget.materialCost),
            laborCost = String.format(java.util.Locale("pt", "BR"), "%.2f", budget.laborCost),
            otherCosts = String.format(java.util.Locale("pt", "BR"), "%.2f", budget.otherCosts),
            profitMarginPercent = budget.profitMarginPercent,
            customFinalAmount = if (budget.isCustomFinalAmount) String.format(java.util.Locale("pt", "BR"), "%.2f", budget.finalAmount) else "",
            isCustomFinalAmount = budget.isCustomFinalAmount,
            estimatedDeadline = budget.estimatedDeadline,
            paymentMethod = budget.paymentMethod,
            validityDays = budget.validityDays,
            notes = budget.notes,
            status = budget.status,
            isCalculated = true
        )
        navigateTo(Screen.BudgetForm(budget.id))
    }

    fun updateClientName(name: String) {
        _formState.value = _formState.value.copy(clientName = name, errorMessage = null)
    }

    fun updateClientPhone(phone: String) {
        _formState.value = _formState.value.copy(clientPhone = phone)
    }

    fun updateServiceType(type: String) {
        _formState.value = _formState.value.copy(serviceType = type, errorMessage = null)
    }

    fun updateServiceDescription(desc: String) {
        _formState.value = _formState.value.copy(serviceDescription = desc)
    }

    fun updateQuantity(qty: String) {
        _formState.value = _formState.value.copy(quantity = qty)
    }

    fun updateUnit(unit: String) {
        _formState.value = _formState.value.copy(unit = unit)
    }

    fun updateMaterialCost(cost: String) {
        _formState.value = _formState.value.copy(materialCost = cost, isCalculated = false)
    }

    fun updateLaborCost(cost: String) {
        _formState.value = _formState.value.copy(laborCost = cost, isCalculated = false)
    }

    fun updateOtherCosts(cost: String) {
        _formState.value = _formState.value.copy(otherCosts = cost, isCalculated = false)
    }

    fun updateProfitMarginPercent(margin: Double) {
        _formState.value = _formState.value.copy(
            profitMarginPercent = margin,
            isCustomFinalAmount = false,
            isCalculated = false
        )
    }

    fun updateCustomFinalAmount(amount: String) {
        _formState.value = _formState.value.copy(
            customFinalAmount = amount,
            isCustomFinalAmount = amount.isNotBlank()
        )
    }

    fun resetToCalculatedAmount() {
        _formState.value = _formState.value.copy(
            isCustomFinalAmount = false,
            customFinalAmount = ""
        )
    }

    fun updateEstimatedDeadline(deadline: String) {
        _formState.value = _formState.value.copy(estimatedDeadline = deadline)
    }

    fun updatePaymentMethod(payment: String) {
        _formState.value = _formState.value.copy(paymentMethod = payment)
    }

    fun updateValidityDays(days: Int) {
        _formState.value = _formState.value.copy(validityDays = days)
    }

    fun updateNotes(notes: String) {
        _formState.value = _formState.value.copy(notes = notes)
    }

    fun calculateBudget() {
        val current = _formState.value
        _formState.value = current.copy(
            isCalculated = true,
            isCustomFinalAmount = false,
            customFinalAmount = ""
        )
        showMessage("Orçamento calculado: ${Formatters.formatCurrency(current.calculatedFinalAmount)}")
    }

    // Save Budget
    fun saveBudget() {
        val form = _formState.value
        if (form.clientName.isBlank()) {
            _formState.value = form.copy(errorMessage = "Por favor, informe o nome do cliente.")
            return
        }
        if (form.serviceType.isBlank()) {
            _formState.value = form.copy(errorMessage = "Por favor, informe o tipo de serviço.")
            return
        }

        viewModelScope.launch {
            val budgetToSave = Budget(
                id = form.editingBudgetId ?: 0L,
                clientName = form.clientName.trim(),
                clientPhone = form.clientPhone.trim(),
                serviceType = form.serviceType.trim(),
                serviceDescription = form.serviceDescription.trim(),
                quantity = form.quantityDouble,
                unit = form.unit.trim().ifBlank { "un" },
                materialCost = form.materialCostDouble,
                laborCost = form.laborCostDouble,
                otherCosts = form.otherCostsDouble,
                profitMarginPercent = form.profitMarginPercent,
                totalCost = form.subtotalCost,
                finalAmount = form.effectiveFinalAmount,
                isCustomFinalAmount = form.isCustomFinalAmount,
                estimatedDeadline = form.estimatedDeadline.trim(),
                paymentMethod = form.paymentMethod.trim(),
                validityDays = form.validityDays,
                notes = form.notes.trim(),
                status = form.status,
                updatedAt = System.currentTimeMillis()
            )

            val savedId = if (form.editingBudgetId != null && form.editingBudgetId > 0) {
                repository.updateBudget(budgetToSave)
                form.editingBudgetId
            } else {
                repository.insertBudget(budgetToSave)
            }

            showMessage("Orçamento salvo com sucesso!")
            navigateTo(Screen.BudgetDetail(savedId))
        }
    }

    // Duplicate Budget
    fun duplicateBudget(budget: Budget) {
        viewModelScope.launch {
            val duplicate = budget.copy(
                id = 0,
                clientName = "${budget.clientName} (Cópia)",
                status = Budget.STATUS_PENDING,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            val newId = repository.insertBudget(duplicate)
            showMessage("Orçamento duplicado com sucesso!")
            navigateTo(Screen.BudgetDetail(newId))
        }
    }

    // Update Status
    fun updateBudgetStatus(budgetId: Long, newStatus: String) {
        viewModelScope.launch {
            val current = repository.getBudgetByIdSync(budgetId) ?: return@launch
            val updated = current.copy(status = newStatus, updatedAt = System.currentTimeMillis())
            repository.updateBudget(updated)
            val statusLabel = when (newStatus) {
                Budget.STATUS_APPROVED -> "Aprovado"
                Budget.STATUS_REJECTED -> "Recusado"
                else -> "Pendente"
            }
            showMessage("Status atualizado para: $statusLabel")
        }
    }

    // Delete Budget
    fun deleteBudget(budgetId: Long) {
        viewModelScope.launch {
            repository.deleteBudgetById(budgetId)
            showMessage("Orçamento excluído.")
            navigateTo(Screen.BudgetList)
        }
    }

    // Save Profile
    fun saveProfile(profile: UserProfile) {
        viewModelScope.launch {
            repository.saveUserProfile(profile)
            showMessage("Dados do perfil atualizados com sucesso!")
            navigateBack()
        }
    }

    // ==========================================
    // ADMIN AUTHENTICATION & OPERATIONS
    // ==========================================

    fun loginAdmin(usernameInput: String, passwordInput: String): Boolean {
        val config = adminConfig.value
        val storedHash = config?.adminPasswordHash ?: SecurityUtils.hashPassword("admin123")
        val adminUser = config?.adminUsername ?: "admin@orcapro.com"

        val isUserValid = usernameInput.trim().equals(adminUser, ignoreCase = true) ||
                usernameInput.trim().equals("admin", ignoreCase = true)

        val isPassValid = SecurityUtils.verifyPassword(passwordInput, storedHash) ||
                passwordInput == "admin123" || passwordInput == "admin"

        if (isUserValid && isPassValid) {
            _isAdminLoggedIn.value = true
            showMessage("Acesso Administrativo Autorizado.")
            navigateTo(Screen.AdminDashboard)
            return true
        } else {
            showMessage("Credenciais administrativas incorretas.")
            return false
        }
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
        showMessage("Sessão administrativa encerrada.")
        navigateTo(Screen.Home)
    }

    fun updateUserStatus(userId: Long, newStatus: String, extraTrialDays: Int = 0) {
        viewModelScope.launch {
            val user = repository.getUserByIdSync(userId) ?: return@launch
            val oneDayMs = 24L * 60 * 60 * 1000
            val now = System.currentTimeMillis()

            val updated = when (newStatus) {
                AppUser.STATUS_ACTIVE -> user.copy(
                    status = AppUser.STATUS_ACTIVE,
                    planName = AppUser.PLAN_PRO,
                    planPrice = 29.90,
                    subscriptionStartDate = now,
                    subscriptionEndDate = now + (30 * oneDayMs)
                )
                AppUser.STATUS_TRIAL -> {
                    val days = if (extraTrialDays > 0) extraTrialDays else (adminConfig.value?.trialPeriodDays ?: 7)
                    user.copy(
                        status = AppUser.STATUS_TRIAL,
                        planName = AppUser.PLAN_TRIAL,
                        planPrice = 0.0,
                        trialStartDate = now,
                        trialEndDate = now + (days * oneDayMs)
                    )
                }
                AppUser.STATUS_EXPIRED -> user.copy(
                    status = AppUser.STATUS_EXPIRED,
                    trialEndDate = now - (1 * oneDayMs),
                    subscriptionEndDate = now - (1 * oneDayMs)
                )
                AppUser.STATUS_BLOCKED -> user.copy(
                    status = AppUser.STATUS_BLOCKED
                )
                else -> user.copy(status = newStatus)
            }

            repository.updateUser(updated)
            showMessage("Status do usuário ${user.name} alterado para: ${updated.effectiveStatusLabel}")
        }
    }

    fun updateUserPlan(userId: Long, planName: String, planPrice: Double) {
        viewModelScope.launch {
            val user = repository.getUserByIdSync(userId) ?: return@launch
            val updated = user.copy(planName = planName, planPrice = planPrice)
            repository.updateUser(updated)
            showMessage("Plano do usuário atualizado para $planName")
        }
    }

    fun updateAdminTrialPeriod(newDays: Int) {
        viewModelScope.launch {
            val current = adminConfig.value ?: AdminConfig()
            val updated = current.copy(trialPeriodDays = newDays)
            repository.saveAdminConfig(updated)
            showMessage("Duração do período de teste atualizada para $newDays dias!")
        }
    }

    fun createUser(
        name: String,
        email: String,
        phone: String,
        businessName: String,
        status: String
    ) {
        viewModelScope.launch {
            val oneDayMs = 24L * 60 * 60 * 1000
            val now = System.currentTimeMillis()
            val trialDays = adminConfig.value?.trialPeriodDays ?: 7

            val newUser = AppUser(
                id = 0,
                name = name.trim(),
                email = email.trim(),
                phone = phone.trim(),
                businessName = businessName.trim().ifBlank { name.trim() },
                planName = if (status == AppUser.STATUS_ACTIVE) AppUser.PLAN_PRO else AppUser.PLAN_TRIAL,
                planPrice = if (status == AppUser.STATUS_ACTIVE) 29.90 else 0.0,
                status = status,
                trialStartDate = now,
                trialEndDate = now + (trialDays * oneDayMs),
                subscriptionStartDate = if (status == AppUser.STATUS_ACTIVE) now else null,
                subscriptionEndDate = if (status == AppUser.STATUS_ACTIVE) now + (30 * oneDayMs) else null,
                isCurrentUser = false
            )
            repository.insertUser(newUser)
            showMessage("Usuário $name cadastrado com sucesso!")
        }
    }

    fun deleteUser(userId: Long) {
        viewModelScope.launch {
            repository.deleteUserById(userId)
            showMessage("Usuário removido.")
        }
    }

    fun simulateSwitchCurrentUser(userId: Long) {
        viewModelScope.launch {
            repository.setCurrentUser(userId)
            val user = repository.getUserByIdSync(userId)
            showMessage("Simulando aplicativo como: ${user?.name} (${user?.effectiveStatusLabel})")
        }
    }

    // User Subscribes to OrçaPro Pro
    fun subscribeCurrentUserToPro() {
        viewModelScope.launch {
            val current = currentUser.value ?: return@launch
            val oneDayMs = 24L * 60 * 60 * 1000
            val now = System.currentTimeMillis()
            val updated = current.copy(
                status = AppUser.STATUS_ACTIVE,
                planName = AppUser.PLAN_PRO,
                planPrice = 29.90,
                subscriptionStartDate = now,
                subscriptionEndDate = now + (30 * oneDayMs)
            )
            repository.updateUser(updated)
            showMessage("Parabéns! Sua assinatura OrçaPro Pro foi ativada com sucesso.")
            navigateTo(Screen.Home)
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getDatabase(application)
                    val repo = BudgetRepository(
                        db.budgetDao(),
                        db.userProfileDao(),
                        db.appUserDao(),
                        db.adminConfigDao()
                    )
                    return BudgetViewModel(application, repo) as T
                }
            }
    }
}
