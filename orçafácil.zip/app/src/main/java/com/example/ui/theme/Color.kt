package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald & Forest Palette
val GreenPrimary = Color(0xFF0F766E)
val GreenPrimaryDark = Color(0xFF14B8A6)
val GreenContainer = Color(0xFFCCFBF1)
val GreenOnContainer = Color(0xFF115E59)

// Slate & Navy Neutrals
val SlateNavy = Color(0xFF1E293B)
val SlateLight = Color(0xFFF1F5F9)
val SlateBorder = Color(0xFFCBD5E1)
val SlateTextSecondary = Color(0xFF64748B)

// Accent & Status Colors
val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppDark = Color(0xFF128C7E)
val StatusPending = Color(0xFFD97706)
val StatusPendingBg = Color(0xFFFEF3C7)
val StatusApproved = Color(0xFF16A34A)
val StatusApprovedBg = Color(0xFFDCFCE7)
val StatusRejected = Color(0xFFDC2626)
val StatusRejectedBg = Color(0xFFFEE2E2)

// Theme M3 Colors
val PrimaryLight = Color(0xFF0F766E)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFCCFBF1)
val OnPrimaryContainerLight = Color(0xFF115E59)

val SecondaryLight = Color(0xFF334155)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFE2E8F0)
val OnSecondaryContainerLight = Color(0xFF1E293B)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)

val PrimaryDark = Color(0xFF2DD4BF)
val OnPrimaryDark = Color(0xFF003731)
val PrimaryContainerDark = Color(0xFF115E59)
val OnPrimaryContainerDark = Color(0xFFCCFBF1)

val SecondaryDark = Color(0xFF94A3B8)
val OnSecondaryDark = Color(0xFF0F172A)
val SecondaryContainerDark = Color(0xFF334155)
val OnSecondaryContainerDark = Color(0xFFE2E8F0)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
