package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.BudgetDetailScreen
import com.example.ui.screens.BudgetFormScreen
import com.example.ui.screens.BudgetListScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PaywallScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.viewmodel.BudgetViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun OrCaFacilApp(
    viewModel: BudgetViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbarMessage()
        }
    }

    // Intercept back button when not on Home
    BackHandler(enabled = currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        val screenModifier = Modifier.padding(innerPadding)
        when (val screen = currentScreen) {
            is Screen.Home -> {
                HomeScreen(viewModel = viewModel, modifier = screenModifier)
            }
            is Screen.BudgetList -> {
                BudgetListScreen(viewModel = viewModel, modifier = screenModifier)
            }
            is Screen.BudgetForm -> {
                BudgetFormScreen(viewModel = viewModel, modifier = screenModifier)
            }
            is Screen.BudgetDetail -> {
                BudgetDetailScreen(
                    budgetId = screen.budgetId,
                    viewModel = viewModel,
                    modifier = screenModifier
                )
            }
            is Screen.Profile -> {
                ProfileScreen(viewModel = viewModel, modifier = screenModifier)
            }
            is Screen.AdminLogin -> {
                AdminLoginScreen(viewModel = viewModel, modifier = screenModifier)
            }
            is Screen.AdminDashboard -> {
                AdminDashboardScreen(viewModel = viewModel, modifier = screenModifier)
            }
            is Screen.Paywall -> {
                PaywallScreen(reason = screen.reason, viewModel = viewModel, modifier = screenModifier)
            }
        }
    }
}
