package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenOnContainer
import com.example.ui.theme.GreenPrimary
import com.example.ui.viewmodel.BudgetViewModel
import com.example.util.Formatters

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetFormScreen(
    viewModel: BudgetViewModel,
    modifier: Modifier = Modifier
) {
    val form by viewModel.formState.collectAsState()
    val isEditing = form.editingBudgetId != null

    val commonUnits = listOf("un", "m²", "m", "horas", "dias", "diárias", "kg", "serviço")
    val commonMargins = listOf(10.0, 20.0, 30.0, 40.0, 50.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isEditing) "Editar Orçamento" else "Novo Orçamento",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("form_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Voltar"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("form_cancel_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Cancelar", fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = { viewModel.saveBudget() },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(50.dp)
                            .testTag("btn_salvar_orcamento"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEditing) "Salvar Alterações" else "Salvar Orçamento",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Error banner if any
            if (form.errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = form.errorMessage ?: "",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(12.dp),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // 1. DADOS DO CLIENTE
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        SectionHeader(title = "Dados do Cliente", icon = Icons.Default.AccountCircle)

                        OutlinedTextField(
                            value = form.clientName,
                            onValueChange = { viewModel.updateClientName(it) },
                            label = { Text("Nome do cliente *") },
                            placeholder = { Text("Ex: Carlos Silva ou Empresa ABC") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_nome_cliente"),
                            singleLine = true,
                            isError = form.errorMessage != null && form.clientName.isBlank()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = form.clientPhone,
                            onValueChange = { viewModel.updateClientPhone(it) },
                            label = { Text("Telefone / WhatsApp") },
                            placeholder = { Text("Ex: (11) 98765-4321") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_telefone_cliente"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true
                        )
                    }
                }
            }

            // 2. SERVIÇO SOLICITADO
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        SectionHeader(title = "Serviço Solicitado", icon = Icons.Default.Build)

                        OutlinedTextField(
                            value = form.serviceType,
                            onValueChange = { viewModel.updateServiceType(it) },
                            label = { Text("Tipo de serviço *") },
                            placeholder = { Text("Ex: Pintura residencial, Instalação elétrica") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_tipo_servico"),
                            singleLine = true,
                            isError = form.errorMessage != null && form.serviceType.isBlank()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = form.serviceDescription,
                            onValueChange = { viewModel.updateServiceDescription(it) },
                            label = { Text("Descrição detalhada do serviço") },
                            placeholder = { Text("Descreva o que será feito, cômodos, etapas ou detalhes...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_descricao_servico"),
                            minLines = 3,
                            maxLines = 5
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = form.quantity,
                                onValueChange = { viewModel.updateQuantity(it) },
                                label = { Text("Quantidade") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_quantidade"),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = form.unit,
                                onValueChange = { viewModel.updateUnit(it) },
                                label = { Text("Unidade") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_unidade"),
                                singleLine = true
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick Unit chips
                        Text(
                            text = "Unidades comuns:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(commonUnits) { unitItem ->
                                FilterChip(
                                    selected = form.unit.equals(unitItem, ignoreCase = true),
                                    onClick = { viewModel.updateUnit(unitItem) },
                                    label = { Text(unitItem, fontSize = 12.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // 3. COMPOSIÇÃO DE CUSTOS & MARGEM
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        SectionHeader(title = "Custos e Margem de Lucro", icon = Icons.Default.MonetizationOn)

                        OutlinedTextField(
                            value = form.materialCost,
                            onValueChange = { viewModel.updateMaterialCost(it) },
                            label = { Text("Valor dos materiais (R$)") },
                            placeholder = { Text("0,00") },
                            prefix = { Text("R$ ", fontWeight = FontWeight.Bold) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_valor_material"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = form.laborCost,
                            onValueChange = { viewModel.updateLaborCost(it) },
                            label = { Text("Valor da mão de obra (R$)") },
                            placeholder = { Text("0,00") },
                            prefix = { Text("R$ ", fontWeight = FontWeight.Bold) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_valor_mao_obra"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = form.otherCosts,
                            onValueChange = { viewModel.updateOtherCosts(it) },
                            label = { Text("Outros custos / Deslocamento (R$)") },
                            placeholder = { Text("0,00") },
                            prefix = { Text("R$ ", fontWeight = FontWeight.Bold) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_outros_custos"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Margem de Lucro
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Margem de Lucro:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${form.profitMarginPercent.toInt()}%",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Slider(
                            value = form.profitMarginPercent.toFloat(),
                            onValueChange = { viewModel.updateProfitMarginPercent(it.toDouble()) },
                            valueRange = 0f..100f,
                            steps = 19,
                            modifier = Modifier.testTag("slider_margem_lucro")
                        )

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(commonMargins) { margin ->
                                FilterChip(
                                    selected = form.profitMarginPercent == margin,
                                    onClick = { viewModel.updateProfitMarginPercent(margin) },
                                    label = { Text("${margin.toInt()}%") }
                                )
                            }
                        }
                    }
                }
            }

            // 4. BOTÃO CALCULAR & RESULTADO DO ORÇAMENTO
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = GreenContainer
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    tint = GreenOnContainer,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Cálculo do Orçamento",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = GreenOnContainer
                                )
                            }

                            Button(
                                onClick = { viewModel.calculateBudget() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GreenPrimary,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("btn_calcular_orcamento")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Calcular", fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Discriminativo de valores
                        CalculationRow(
                            label = "Custo dos Materiais:",
                            value = Formatters.formatCurrency(form.materialCostDouble)
                        )
                        CalculationRow(
                            label = "Mão de Obra:",
                            value = Formatters.formatCurrency(form.laborCostDouble)
                        )
                        if (form.otherCostsDouble > 0) {
                            CalculationRow(
                                label = "Outros Custos:",
                                value = Formatters.formatCurrency(form.otherCostsDouble)
                            )
                        }
                        CalculationRow(
                            label = "Custo Total Direto:",
                            value = Formatters.formatCurrency(form.subtotalCost),
                            isBold = true
                        )
                        CalculationRow(
                            label = "Lucro (${form.profitMarginPercent.toInt()}%):",
                            value = "+ ${Formatters.formatCurrency(form.profitAmount)}",
                            color = GreenPrimary
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(GreenOnContainer.copy(alpha = 0.2f))
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Valor Final Grande
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "VALOR FINAL:",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = GreenOnContainer
                            )
                            Text(
                                text = Formatters.formatCurrency(form.effectiveFinalAmount),
                                fontWeight = FontWeight.Black,
                                fontSize = 22.sp,
                                color = GreenPrimary
                            )
                        }

                        // Edição manual do valor final
                        Spacer(modifier = Modifier.height(12.dp))
                        if (form.isCustomFinalAmount) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Valor editado manualmente",
                                    fontSize = 12.sp,
                                    color = GreenOnContainer,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Restaurar calculado",
                                    fontSize = 12.sp,
                                    color = GreenPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clickable { viewModel.resetToCalculatedAmount() }
                                        .padding(4.dp)
                                )
                            }
                        }

                        OutlinedTextField(
                            value = if (form.isCustomFinalAmount) form.customFinalAmount else String.format(java.util.Locale("pt", "BR"), "%.2f", form.calculatedFinalAmount),
                            onValueChange = { viewModel.updateCustomFinalAmount(it) },
                            label = { Text("Ajustar valor final manualmente (opcional)") },
                            prefix = { Text("R$ ", fontWeight = FontWeight.Bold) },
                            trailingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Editar valor final",
                                    tint = GreenPrimary
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_valor_final_manual"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White
                            )
                        )
                    }
                }
            }

            // 5. CONDIÇÕES COMERCIAIS
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        SectionHeader(title = "Condições do Orçamento", icon = Icons.Default.DateRange)

                        OutlinedTextField(
                            value = form.estimatedDeadline,
                            onValueChange = { viewModel.updateEstimatedDeadline(it) },
                            label = { Text("Prazo estimado de execução") },
                            placeholder = { Text("Ex: 3 a 5 dias úteis, 1 semana") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_prazo_estimado"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = form.paymentMethod,
                            onValueChange = { viewModel.updatePaymentMethod(it) },
                            label = { Text("Forma de pagamento") },
                            placeholder = { Text("Ex: Pix, 50% entrada e 50% entrega, Cartão") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_forma_pagamento"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Validade da proposta: ${form.validityDays} dias",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                        }
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            items(listOf(7, 10, 15, 30)) { days ->
                                FilterChip(
                                    selected = form.validityDays == days,
                                    onClick = { viewModel.updateValidityDays(days) },
                                    label = { Text("$days dias") }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = form.notes,
                            onValueChange = { viewModel.updateNotes(it) },
                            label = { Text("Observações adicionais e garantia") },
                            placeholder = { Text("Ex: Garantia de 90 dias, materiais por conta do cliente...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_observacoes"),
                            minLines = 2,
                            maxLines = 4
                        )
                    }
                }
            }

            // Bottom spacing so list doesn't get covered by bottom bar
            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun CalculationRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    color: Color = Color.Unspecified
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (color != Color.Unspecified) color else GreenOnContainer
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (color != Color.Unspecified) color else GreenOnContainer
        )
    }
}
