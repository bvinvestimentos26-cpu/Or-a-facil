package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "admin_config")
data class AdminConfig(
    @PrimaryKey
    val id: Int = 1,
    val adminUsername: String = "admin@orcapro.com",
    val adminPasswordHash: String = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918", // SHA-256 for "admin123"
    val trialPeriodDays: Int = 7,
    val proPlanName: String = "OrçaPro Pro",
    val proPlanPriceMonthly: Double = 29.90
)
