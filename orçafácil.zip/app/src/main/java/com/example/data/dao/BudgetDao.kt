package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Budget
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets ORDER BY createdAt DESC")
    fun getAllBudgets(): Flow<List<Budget>>

    @Query("SELECT * FROM budgets WHERE id = :id")
    fun getBudgetById(id: Long): Flow<Budget?>

    @Query("SELECT * FROM budgets WHERE id = :id")
    suspend fun getBudgetByIdSync(id: Long): Budget?

    @Query("SELECT * FROM budgets WHERE status = :status ORDER BY createdAt DESC")
    fun getBudgetsByStatus(status: String): Flow<List<Budget>>

    @Query("""
        SELECT * FROM budgets 
        WHERE clientName LIKE '%' || :query || '%' 
           OR serviceType LIKE '%' || :query || '%' 
           OR serviceDescription LIKE '%' || :query || '%'
        ORDER BY createdAt DESC
    """)
    fun searchBudgets(query: String): Flow<List<Budget>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudget(budget: Budget): Long

    @Update
    suspend fun updateBudget(budget: Budget)

    @Delete
    suspend fun deleteBudget(budget: Budget)

    @Query("DELETE FROM budgets WHERE id = :id")
    suspend fun deleteBudgetById(id: Long)
}
