package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val clientName: String,
    val clientPhone: String = "",
    val serviceType: String,
    val serviceDescription: String = "",
    val quantity: Double = 1.0,
    val unit: String = "un",
    val materialCost: Double = 0.0,
    val laborCost: Double = 0.0,
    val otherCosts: Double = 0.0,
    val profitMarginPercent: Double = 20.0,
    val totalCost: Double = 0.0,
    val finalAmount: Double = 0.0,
    val isCustomFinalAmount: Boolean = false,
    val estimatedDeadline: String = "3 a 5 dias úteis",
    val paymentMethod: String = "Pix, Dinheiro ou Cartão",
    val validityDays: Int = 15,
    val notes: String = "",
    val status: String = STATUS_PENDING,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_PENDING = "PENDENTE"
        const val STATUS_APPROVED = "APROVADO"
        const val STATUS_REJECTED = "RECUSADO"
    }

    val profitAmount: Double
        get() = if (isCustomFinalAmount) {
            (finalAmount - totalCost).coerceAtLeast(0.0)
        } else {
            totalCost * (profitMarginPercent / 100.0)
        }
}
