package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_users")
data class AppUser(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val email: String,
    val phone: String,
    val businessName: String,
    val planName: String = PLAN_PRO,
    val planPrice: Double = 29.90,
    val status: String = STATUS_TRIAL, // TESTE_GRATIS, ATIVO, VENCIDO, BLOQUEADO
    val trialStartDate: Long = System.currentTimeMillis(),
    val trialEndDate: Long = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000),
    val subscriptionStartDate: Long? = null,
    val subscriptionEndDate: Long? = null,
    val isCurrentUser: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_TRIAL = "TESTE_GRATIS"
        const val STATUS_ACTIVE = "ATIVO"
        const val STATUS_EXPIRED = "VENCIDO"
        const val STATUS_BLOCKED = "BLOQUEADO"

        const val PLAN_PRO = "OrçaPro Pro"
        const val PLAN_TRIAL = "Teste Grátis"
    }

    val isTrialActive: Boolean
        get() = status == STATUS_TRIAL && System.currentTimeMillis() <= trialEndDate

    val remainingTrialDays: Int
        get() {
            if (status != STATUS_TRIAL) return 0
            val diffMs = trialEndDate - System.currentTimeMillis()
            return if (diffMs > 0) ((diffMs / (24L * 60 * 60 * 1000)) + 1).toInt() else 0
        }

    val isAccessAllowed: Boolean
        get() = when (status) {
            STATUS_ACTIVE -> true
            STATUS_TRIAL -> isTrialActive
            STATUS_EXPIRED -> false
            STATUS_BLOCKED -> false
            else -> false
        }

    val effectiveStatusLabel: String
        get() = when (status) {
            STATUS_TRIAL -> if (isTrialActive) "Teste Grátis ($remainingTrialDays dias)" else "Teste Expirado"
            STATUS_ACTIVE -> "Assinatura Ativa"
            STATUS_EXPIRED -> "Assinatura Vencida"
            STATUS_BLOCKED -> "Bloqueado"
            else -> status
        }
}
