package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey
    val id: Int = 1,
    val businessName: String = "OrçaFácil Serviços",
    val professionalName: String = "Profissional Autônomo",
    val phone: String = "(11) 99999-9999",
    val whatsapp: String = "(11) 99999-9999",
    val email: String = "contato@orcafacil.com",
    val address: String = "São Paulo - SP",
    val pixKey: String = "",
    val defaultPaymentTerms: String = "50% de entrada + 50% na entrega",
    val defaultValidityDays: Int = 15,
    val defaultNotes: String = "Garantia de 90 dias sobre a mão de obra. Orçamento sujeito a alteração caso haja mudanças no projeto."
)
