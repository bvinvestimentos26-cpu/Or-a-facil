package com.example.data.repository

import com.example.data.dao.AdminConfigDao
import com.example.data.dao.AppUserDao
import com.example.data.dao.BudgetDao
import com.example.data.dao.UserProfileDao
import com.example.data.model.AdminConfig
import com.example.data.model.AppUser
import com.example.data.model.Budget
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow

class BudgetRepository(
    private val budgetDao: BudgetDao,
    private val userProfileDao: UserProfileDao,
    private val appUserDao: AppUserDao,
    private val adminConfigDao: AdminConfigDao
) {
    // Budgets
    fun getAllBudgets(): Flow<List<Budget>> = budgetDao.getAllBudgets()

    fun getBudgetById(id: Long): Flow<Budget?> = budgetDao.getBudgetById(id)

    suspend fun getBudgetByIdSync(id: Long): Budget? = budgetDao.getBudgetByIdSync(id)

    fun searchBudgets(query: String): Flow<List<Budget>> = budgetDao.searchBudgets(query)

    suspend fun insertBudget(budget: Budget): Long = budgetDao.insertBudget(budget)

    suspend fun updateBudget(budget: Budget) = budgetDao.updateBudget(budget)

    suspend fun deleteBudget(budget: Budget) = budgetDao.deleteBudget(budget)

    suspend fun deleteBudgetById(id: Long) = budgetDao.deleteBudgetById(id)

    // User Profile
    fun getUserProfile(): Flow<UserProfile?> = userProfileDao.getUserProfile()

    suspend fun getUserProfileSync(): UserProfile? = userProfileDao.getUserProfileSync()

    suspend fun saveUserProfile(profile: UserProfile) = userProfileDao.upsertUserProfile(profile)

    // App Users & Admin
    fun getAllUsers(): Flow<List<AppUser>> = appUserDao.getAllUsers()

    fun getUserById(id: Long): Flow<AppUser?> = appUserDao.getUserById(id)

    suspend fun getUserByIdSync(id: Long): AppUser? = appUserDao.getUserByIdSync(id)

    fun getCurrentUser(): Flow<AppUser?> = appUserDao.getCurrentUser()

    suspend fun getCurrentUserSync(): AppUser? = appUserDao.getCurrentUserSync()

    fun searchUsers(query: String): Flow<List<AppUser>> = appUserDao.searchUsers(query)

    suspend fun insertUser(user: AppUser): Long = appUserDao.insertUser(user)

    suspend fun updateUser(user: AppUser) = appUserDao.updateUser(user)

    suspend fun deleteUser(user: AppUser) = appUserDao.deleteUser(user)

    suspend fun deleteUserById(id: Long) = appUserDao.deleteUserById(id)

    suspend fun setCurrentUser(userId: Long) {
        appUserDao.clearCurrentUserFlag()
        appUserDao.setCurrentUserFlag(userId)
    }

    // Admin Config
    fun getAdminConfig(): Flow<AdminConfig?> = adminConfigDao.getConfig()

    suspend fun getAdminConfigSync(): AdminConfig? = adminConfigDao.getConfigSync()

    suspend fun saveAdminConfig(config: AdminConfig) = adminConfigDao.upsertConfig(config)
}
