package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppUser
import kotlinx.coroutines.flow.Flow

@Dao
interface AppUserDao {
    @Query("SELECT * FROM app_users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<AppUser>>

    @Query("SELECT * FROM app_users WHERE id = :id")
    fun getUserById(id: Long): Flow<AppUser?>

    @Query("SELECT * FROM app_users WHERE id = :id")
    suspend fun getUserByIdSync(id: Long): AppUser?

    @Query("SELECT * FROM app_users WHERE isCurrentUser = 1 LIMIT 1")
    fun getCurrentUser(): Flow<AppUser?>

    @Query("SELECT * FROM app_users WHERE isCurrentUser = 1 LIMIT 1")
    suspend fun getCurrentUserSync(): AppUser?

    @Query("SELECT * FROM app_users WHERE name LIKE '%' || :query || '%' OR email LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' OR businessName LIKE '%' || :query || '%'")
    fun searchUsers(query: String): Flow<List<AppUser>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: AppUser): Long

    @Update
    suspend fun updateUser(user: AppUser)

    @Delete
    suspend fun deleteUser(user: AppUser)

    @Query("DELETE FROM app_users WHERE id = :id")
    suspend fun deleteUserById(id: Long)

    @Query("UPDATE app_users SET isCurrentUser = 0 WHERE isCurrentUser = 1")
    suspend fun clearCurrentUserFlag()

    @Query("UPDATE app_users SET isCurrentUser = 1 WHERE id = :id")
    suspend fun setCurrentUserFlag(id: Long)
}
