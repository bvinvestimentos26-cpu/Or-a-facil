package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AdminConfigDao
import com.example.data.dao.AppUserDao
import com.example.data.dao.BudgetDao
import com.example.data.dao.UserProfileDao
import com.example.data.model.AdminConfig
import com.example.data.model.AppUser
import com.example.data.model.Budget
import com.example.data.model.UserProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Budget::class,
        UserProfile::class,
        AppUser::class,
        AdminConfig::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun budgetDao(): BudgetDao
    abstract fun userProfileDao(): UserProfileDao
    abstract fun appUserDao(): AppUserDao
    abstract fun adminConfigDao(): AdminConfigDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "orcafacil_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        // Prepopulate default user profile
                        database.userProfileDao().upsertUserProfile(
                            UserProfile(
                                id = 1,
                                businessName = "Silva Reformas & Serviços",
                                professionalName = "Carlos Silva",
                                phone = "(11) 98765-4321",
                                whatsapp = "(11) 98765-4321",
                                email = "carlos.silva@email.com",
                                address = "São Paulo, SP",
                                pixKey = "11987654321",
                                defaultPaymentTerms = "50% de entrada + 50% na conclusão",
                                defaultValidityDays = 15,
                                defaultNotes = "Garantia de 90 dias nos serviços prestados. Orçamento válido pelo prazo informado."
                            )
                        )

                        // Prepopulate Admin Config
                        database.adminConfigDao().upsertConfig(
                            AdminConfig(
                                id = 1,
                                adminUsername = "admin@orcapro.com",
                                adminPasswordHash = "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918", // "admin123"
                                trialPeriodDays = 7,
                                proPlanName = "OrçaPro Pro",
                                proPlanPriceMonthly = 29.90
                            )
                        )

                        val now = System.currentTimeMillis()
                        val oneDayMs = 24L * 60 * 60 * 1000

                        // Prepopulate current user (in active trial)
                        database.appUserDao().insertUser(
                            AppUser(
                                id = 1,
                                name = "Carlos Silva",
                                email = "carlos.silva@email.com",
                                phone = "(11) 98765-4321",
                                businessName = "Silva Reformas & Serviços",
                                planName = AppUser.PLAN_PRO,
                                planPrice = 29.90,
                                status = AppUser.STATUS_TRIAL,
                                trialStartDate = now - (2 * oneDayMs),
                                trialEndDate = now + (5 * oneDayMs),
                                isCurrentUser = true
                            )
                        )

                        // Sample Users for Admin Dashboard & Management
                        database.appUserDao().insertUser(
                            AppUser(
                                id = 2,
                                name = "Mariana Oliveira",
                                email = "mariana.eletrica@gmail.com",
                                phone = "(11) 97123-4567",
                                businessName = "Mariana Instalações Elétricas",
                                planName = AppUser.PLAN_PRO,
                                planPrice = 29.90,
                                status = AppUser.STATUS_ACTIVE,
                                trialStartDate = now - (40 * oneDayMs),
                                trialEndDate = now - (33 * oneDayMs),
                                subscriptionStartDate = now - (33 * oneDayMs),
                                subscriptionEndDate = now + (27 * oneDayMs),
                                isCurrentUser = false
                            )
                        )

                        database.appUserDao().insertUser(
                            AppUser(
                                id = 3,
                                name = "Roberto Santos",
                                email = "roberto.pinturas@hotmail.com",
                                phone = "(21) 98877-6655",
                                businessName = "Santos Pinturas & Acabamentos",
                                planName = AppUser.PLAN_PRO,
                                planPrice = 29.90,
                                status = AppUser.STATUS_ACTIVE,
                                trialStartDate = now - (60 * oneDayMs),
                                trialEndDate = now - (53 * oneDayMs),
                                subscriptionStartDate = now - (53 * oneDayMs),
                                subscriptionEndDate = now + (7 * oneDayMs),
                                isCurrentUser = false
                            )
                        )

                        database.appUserDao().insertUser(
                            AppUser(
                                id = 4,
                                name = "Fernanda Costa",
                                email = "fernanda.marcenaria@outlook.com",
                                phone = "(31) 99345-6789",
                                businessName = "Costa Marcenaria & Design",
                                planName = AppUser.PLAN_PRO,
                                planPrice = 29.90,
                                status = AppUser.STATUS_TRIAL,
                                trialStartDate = now - (1 * oneDayMs),
                                trialEndDate = now + (6 * oneDayMs),
                                isCurrentUser = false
                            )
                        )

                        database.appUserDao().insertUser(
                            AppUser(
                                id = 5,
                                name = "Lucas Mendes",
                                email = "lucas.hidraulica@yahoo.com",
                                phone = "(41) 98112-3344",
                                businessName = "Mendes Serviços Hidráulicos",
                                planName = AppUser.PLAN_PRO,
                                planPrice = 29.90,
                                status = AppUser.STATUS_EXPIRED,
                                trialStartDate = now - (20 * oneDayMs),
                                trialEndDate = now - (13 * oneDayMs),
                                subscriptionStartDate = null,
                                subscriptionEndDate = null,
                                isCurrentUser = false
                            )
                        )

                        database.appUserDao().insertUser(
                            AppUser(
                                id = 6,
                                name = "Alexandre Souza",
                                email = "alexandre.reformas@gmail.com",
                                phone = "(81) 98777-1122",
                                businessName = "Souza Climatização",
                                planName = AppUser.PLAN_PRO,
                                planPrice = 29.90,
                                status = AppUser.STATUS_BLOCKED,
                                trialStartDate = now - (90 * oneDayMs),
                                trialEndDate = now - (83 * oneDayMs),
                                isCurrentUser = false
                            )
                        )
                    }
                }
            }
        }
    }
}
