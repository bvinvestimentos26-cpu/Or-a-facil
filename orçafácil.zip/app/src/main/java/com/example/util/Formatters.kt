package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.data.model.Budget
import com.example.data.model.UserProfile
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formatters {
    private val ptBrLocale = Locale("pt", "BR")
    private val currencyFormat = NumberFormat.getCurrencyInstance(ptBrLocale)
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", ptBrLocale)
    private val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", ptBrLocale)

    fun formatCurrency(value: Double): String {
        return try {
            currencyFormat.format(value)
        } catch (e: Exception) {
            "R$ ${String.format(ptBrLocale, "%.2f", value)}"
        }
    }

    fun formatDate(timestamp: Long): String {
        return try {
            dateFormat.format(Date(timestamp))
        } catch (e: Exception) {
            ""
        }
    }

    fun formatDateTime(timestamp: Long): String {
        return try {
            dateTimeFormat.format(Date(timestamp))
        } catch (e: Exception) {
            ""
        }
    }

    fun parseNumber(text: String): Double {
        if (text.isBlank()) return 0.0
        val sanitized = text
            .replace("R$", "")
            .replace(" ", "")
            .replace(".", "")
            .replace(",", ".")
            .trim()
        return sanitized.toDoubleOrNull() ?: 0.0
    }
}

object ShareHelper {
    fun generateBudgetText(budget: Budget, profile: UserProfile?): String {
        val sb = StringBuilder()
        val emi = profile?.businessName?.takeIf { it.isNotBlank() }
            ?: profile?.professionalName?.takeIf { it.isNotBlank() }
            ?: "OrçaFácil Serviços"

        sb.append("📋 *ORÇAMENTO DE SERVIÇO*\n")
        sb.append("═══════════════════════\n")
        sb.append("🏢 *Prestador:* $emi\n")
        if (!profile?.whatsapp.isNullOrBlank()) {
            sb.append("📞 *Contato/WhatsApp:* ${profile?.whatsapp}\n")
        }
        if (!profile?.email.isNullOrBlank()) {
            sb.append("✉️ *E-mail:* ${profile?.email}\n")
        }
        if (!profile?.address.isNullOrBlank()) {
            sb.append("📍 *Localização:* ${profile?.address}\n")
        }

        sb.append("\n👤 *Cliente:* ${budget.clientName}\n")
        if (budget.clientPhone.isNotBlank()) {
            sb.append("📱 *Telefone:* ${budget.clientPhone}\n")
        }
        sb.append("📅 *Data:* ${Formatters.formatDate(budget.createdAt)}\n")
        sb.append("⏳ *Validade:* ${budget.validityDays} dias\n")
        sb.append("───────────────────────\n")

        sb.append("🛠️ *Serviço:* ${budget.serviceType}\n")
        if (budget.serviceDescription.isNotBlank()) {
            sb.append("📝 *Descrição:* ${budget.serviceDescription}\n")
        }
        sb.append("📊 *Quantidade:* ${budget.quantity} ${budget.unit}\n")
        
        sb.append("───────────────────────\n")
        sb.append("💰 *VALOR TOTAL:* *${Formatters.formatCurrency(budget.finalAmount)}*\n")
        sb.append("───────────────────────\n")

        if (budget.estimatedDeadline.isNotBlank()) {
            sb.append("⏱️ *Prazo estimado:* ${budget.estimatedDeadline}\n")
        }
        if (budget.paymentMethod.isNotBlank()) {
            sb.append("💳 *Forma de pagamento:* ${budget.paymentMethod}\n")
        }
        if (!profile?.pixKey.isNullOrBlank()) {
            sb.append("🔑 *Chave Pix:* ${profile?.pixKey}\n")
        }
        if (budget.notes.isNotBlank()) {
            sb.append("📌 *Observações:* ${budget.notes}\n")
        }

        sb.append("\n_Agradecemos a confiança e preferência! Ficamos à disposição para dúvidas._")
        return sb.toString()
    }

    fun openWhatsApp(context: Context, budget: Budget, profile: UserProfile?) {
        val text = generateBudgetText(budget, profile)
        val cleanPhone = budget.clientPhone.replace(Regex("[^0-9]"), "")
        
        val phoneParam = if (cleanPhone.isNotBlank()) {
            val fullPhone = if (cleanPhone.length in 10..11) "55$cleanPhone" else cleanPhone
            fullPhone
        } else ""

        try {
            val encodedText = Uri.encode(text)
            val uri = if (phoneParam.isNotBlank()) {
                Uri.parse("https://api.whatsapp.com/send?phone=$phoneParam&text=$encodedText")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=$encodedText")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // If direct URL fails, fallback to general ACTION_SEND or Toast
            try {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(sendIntent)
            } catch (e2: Exception) {
                Toast.makeText(
                    context,
                    "WhatsApp não encontrado. Abrindo opções de compartilhamento...",
                    Toast.LENGTH_SHORT
                ).show()
                shareNative(context, budget, profile)
            }
        }
    }

    fun shareNative(context: Context, budget: Budget, profile: UserProfile?) {
        try {
            val text = generateBudgetText(budget, profile)
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Orçamento - ${budget.clientName} (${budget.serviceType})")
                putExtra(Intent.EXTRA_TEXT, text)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val chooser = Intent.createChooser(sendIntent, "Compartilhar Orçamento via...").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "Erro ao compartilhar: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun dialPhone(context: Context, phone: String) {
        val cleanPhone = phone.replace(Regex("[^0-9+]"), "")
        if (cleanPhone.isBlank()) {
            Toast.makeText(context, "Telefone não informado", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Não foi possível abrir o discador", Toast.LENGTH_SHORT).show()
        }
    }
}
